import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';
import 'permission_service.dart';

class LocationService {
  // Get current position
  static Future<Position?> getCurrentPosition() async {
    try {
      // First check if location service is enabled
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        print('Location services are disabled');
        return null;
      }
      
      // Check location permission
      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          print('Location permission denied');
          return null;
        }
      }
      
      if (permission == LocationPermission.deniedForever) {
        print('Location permission permanently denied');
        return null;
      }
      
      // Get current position
      print('Getting current position');
      return await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );
    } catch (e) {
      print('Error getting location: $e');
      return getMockPosition();
    }
  }
  
  // Get mock position when location service fails
  static Position getMockPosition() {
    print('Returning mock position');
    // Jakarta coordinates
    return Position(
      latitude: -6.2088,
      longitude: 106.8456,
      timestamp: DateTime.now(),
      accuracy: 0,
      altitude: 0,
      heading: 0,
      speed: 0,
      speedAccuracy: 0,
      altitudeAccuracy: 0,
      headingAccuracy: 0,
    );
  }

  // Get place name from coordinates
  static Future<String?> getPlaceFromCoordinates(double latitude, double longitude) async {
    try {
      List<Placemark> placemarks = await placemarkFromCoordinates(latitude, longitude);
      
      if (placemarks.isNotEmpty) {
        Placemark place = placemarks.first;
        
        // Try to get the most specific location name
        // Prefer subLocality (village/neighborhood) if available
        if (place.subLocality != null && place.subLocality!.isNotEmpty) {
          return place.subLocality;
        }
        // Fall back to locality (city/town)
        else if (place.locality != null && place.locality!.isNotEmpty) {
          return place.locality;
        }
        // Fall back to subAdministrativeArea (district/county)
        else if (place.subAdministrativeArea != null && place.subAdministrativeArea!.isNotEmpty) {
          return place.subAdministrativeArea;
        }
        // Last resort: administrative area (state/province)
        else {
          return place.administrativeArea ?? 'Unknown Location';
        }
      }
      
      return null;
    } catch (e) {
      print('Error getting place name: $e');
      // Return a more specific mock location
      return 'Cibinong';
    }
  }
}

