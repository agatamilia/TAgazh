import 'dart:convert';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:http/http.dart' as http;
import '../config/api_config.dart';
import '../models/weather_data.dart';
import '../models/message.dart';
import '../models/chat_session.dart';

class ApiService {
  final Dio _dio = Dio();

  ApiService() {
    // Configure Dio with longer timeouts
    _dio.options.connectTimeout = Duration(seconds: ApiConfig.connectTimeout);
    _dio.options.receiveTimeout = Duration(seconds: ApiConfig.receiveTimeout);
    _dio.options.validateStatus = (status) {
      return status != null && status < 500;
    };
    
    // Add logging interceptor
    _dio.interceptors.add(LogInterceptor(
      requestBody: true,
      responseBody: true,
      error: true,
    ));
    
    print('API Service initialized with base URL: ${ApiConfig.baseUrl}');
    print('Connect timeout: ${ApiConfig.connectTimeout} seconds');
    print('Receive timeout: ${ApiConfig.receiveTimeout} seconds');
  }

  // Session management
  Future<List<ChatSession>> getSessions() async {
    try {
      print('Fetching sessions from backend');
      final response = await _dio.get('${ApiConfig.baseUrl}/api/sessions');
      
      if (response.statusCode == 200) {
        final List<dynamic> data = response.data;
        return data.map((json) => ChatSession.fromMap(json)).toList();
      } else {
        print('Error fetching sessions: ${response.statusCode}');
        throw Exception('Failed to load sessions');
      }
    } catch (e) {
      print('Error getting sessions: $e');
      // Return empty list on error
      return [];
    }
  }

  Future<ChatSession> createSession(String name) async {
    try {
      print('Creating new session: $name');
      final response = await _dio.post(
        '${ApiConfig.baseUrl}/api/sessions',
        data: {'name': name},
      );
      
      if (response.statusCode == 200) {
        return ChatSession.fromMap(response.data);
      } else {
        print('Error creating session: ${response.statusCode}');
        throw Exception('Failed to create session');
      }
    } catch (e) {
      print('Error creating session: $e');
      // Create a local session as fallback
      final id = DateTime.now().millisecondsSinceEpoch.toString();
      return ChatSession(
        id: id,
        name: name,
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );
    }
  }

  Future<void> updateSession(ChatSession session) async {
    try {
      print('Updating session: ${session.id}');
      await _dio.put(
        '${ApiConfig.baseUrl}/api/sessions/${session.id}',
        data: {'name': session.name},
      );
    } catch (e) {
      print('Error updating session: $e');
    }
  }

  Future<void> deleteSession(String sessionId) async {
    try {
      print('Deleting session: $sessionId');
      await _dio.delete('${ApiConfig.baseUrl}/api/sessions/$sessionId');
    } catch (e) {
      print('Error deleting session: $e');
    }
  }

  // Message management
  Future<List<ChatMessage>> getMessages(String sessionId) async {
    try {
      print('Fetching messages for session: $sessionId');
      final response = await _dio.get(
        '${ApiConfig.baseUrl}/api/sessions/$sessionId/messages',
      );
      
      if (response.statusCode == 200) {
        final List<dynamic> data = response.data;
        return data.map((json) => ChatMessage.fromMap(json)).toList();
      } else {
        print('Error fetching messages: ${response.statusCode}');
        throw Exception('Failed to load messages');
      }
    } catch (e) {
      print('Error getting messages: $e');
      // Return empty list on error
      return [];
    }
  }

  Future<void> saveMessage(ChatMessage message, String sessionId) async {
    try {
      print('Saving message to session: $sessionId');
      await _dio.post(
        '${ApiConfig.baseUrl}/api/sessions/$sessionId/messages',
        data: {
          'content': message.content,
          'role': message.role == MessageRole.user ? 'user' : 'assistant',
          'image_path': message.imageUrl,
        },
      );
    } catch (e) {
      print('Error saving message: $e');
    }
  }

  Future<void> deleteMessage(String sessionId, String messageId) async {
    try {
      print('Deleting message: $messageId from session: $sessionId');
      await _dio.delete(
        '${ApiConfig.baseUrl}/api/sessions/$sessionId/messages/$messageId',
      );
    } catch (e) {
      print('Error deleting message: $e');
    }
  }

  Future<void> clearMessages(String sessionId) async {
    try {
      print('Clearing all messages from session: $sessionId');
      await _dio.delete(
        '${ApiConfig.baseUrl}/api/sessions/$sessionId/messages',
      );
    } catch (e) {
      print('Error clearing messages: $e');
    }
  }

  // Get weather data based on location
  Future<WeatherData> getWeather(double latitude, double longitude) async {
    try {
      print('Fetching weather data for lat: $latitude, lon: $longitude');
      print('URL: ${ApiConfig.baseUrl}/api/weather?lat=$latitude&lon=$longitude');
      
      final response = await _dio.get(
        '${ApiConfig.baseUrl}/api/weather',
        queryParameters: {
          'lat': latitude,
          'lon': longitude,
        },
      );
      
      print('Weather API response status: ${response.statusCode}');
      
      if (response.statusCode == 200) {
        final data = response.data;
        print('Weather data received: $data');
        return WeatherData.fromJson(data);
      } else {
        print('Weather API error: ${response.data}');
        throw Exception('Failed to load weather data: ${response.data}');
      }
    } catch (e) {
      print('Error getting weather data: $e');
      // Return mock weather data when API fails
      return _getMockWeatherData();
    }
  }

  // Mock weather data for when the API is unavailable
  WeatherData _getMockWeatherData() {
    print('Returning mock weather data');
    return WeatherData(
      temperature: 30.0,
      condition: 'sunny',
      description: 'Cerah',
      location: 'Cibinong',
      advice: 'Cocok untuk panen atau pengeringan hasil panen',
    );
  }

  // Send message to chatbot
  Future<Map<String, dynamic>> sendMessage(String message, String sessionId) async {
    try {
      print('Sending message to chatbot: $message');
      print('URL: ${ApiConfig.baseUrl}/api/chat');
      
      final response = await _dio.post(
        '${ApiConfig.baseUrl}/api/chat',
        data: {
          'message': message,
          'session_id': sessionId,
        },
        options: Options(
          headers: {'Content-Type': 'application/json'},
        ),
      );
      
      print('Chat API response status: ${response.statusCode}');
      
      if (response.statusCode == 200) {
        final data = response.data;
        print('Chat response received: $data');
        return {
          'response': data['response'],
          'is_farming_related': data['is_farming_related'] ?? true
        };
      } else {
        print('Chat API error: ${response.data}');
        throw Exception('Failed to get chat response: ${response.data}');
      }
    } catch (e) {
      print('Error sending message: $e');
      // Return mock response when API fails
      return _getMockChatResponse(message);
    }
  }

  // Mock chat response for when the API is unavailable
  Map<String, dynamic> _getMockChatResponse(String message) {
    print('Returning mock chat response');
    
    // Check if the message is agriculture-related
    final isAgricultureRelated = _isAgricultureRelated(message);
    
    if (isAgricultureRelated) {
      return {
        'response': _generateAgricultureResponse(message),
        'is_farming_related': true
      };
    } else {
      return {
        'response': 'Maaf, saya hanya dapat menjawab pertanyaan seputar pertanian, perkebunan, dan peternakan. Untuk pert  saya hanya dapat menjawab pertanyaan seputar pertanian, perkebunan, dan peternakan. Untuk pertanyaan lain, silakan kunjungi DeepSeek AI di https://deepseek.ai',
        'is_farming_related': false
      };
    }
  }

  bool _isAgricultureRelated(String message) {
    final agricultureKeywords = [
      // Farming
      'tani', 'pertanian', 'padi', 'sawah', 'kebun', 'tanaman', 'pupuk', 'hama', 
      'pestisida', 'irigasi', 'panen', 'benih', 'bibit', 'hasil panen',
      
      // Plants and crops
      'buah', 'sayur', 'sayuran', 'bunga', 'pohon', 'rumput', 'gulma', 'jagung',
      'kedelai', 'kacang', 'cabai', 'tomat', 'kentang', 'wortel', 'bawang',
      
      // Environment
      'tanah', 'air', 'hujan', 'kemarau', 'musim', 'cuaca', 'iklim', 'banjir', 'kekeringan',
      
      // Equipment
      'traktor', 'alat', 'mesin', 'cangkul', 'sabit', 'arit', 'bajak',
      
      // Livestock
      'ternak', 'sapi', 'kambing', 'ayam', 'bebek', 'ikan', 'tambak', 'kandang',
      
      // Agriculture business
      'harga', 'pasar', 'jual', 'beli', 'ekspor', 'impor', 'distribusi',
      
      // English terms
      'farm', 'crop', 'plant', 'seed', 'harvest', 'soil', 'water', 'fertilizer',
      'pest', 'weather', 'season', 'irrigation', 'cultivation', 'agriculture',
      'livestock', 'cattle', 'poultry', 'fish', 'farming'
    ];
    
    final lowerMessage = message.toLowerCase();
    
    for (final keyword in agricultureKeywords) {
      if (lowerMessage.contains(keyword.toLowerCase())) {
        return true;
      }
    }
    
    return false;
  }

  String _generateAgricultureResponse(String message) {
    // Simple response generator based on keywords
    final lowerMessage = message.toLowerCase();
    
    if (lowerMessage.contains('padi') || lowerMessage.contains('beras')) {
      return 'Padi adalah tanaman pangan utama di Indonesia. Untuk menanam padi dengan baik, Anda perlu memperhatikan kualitas bibit, pengairan yang cukup, dan pengendalian hama. Waktu tanam yang tepat juga sangat penting untuk hasil yang optimal.';
    } else if (lowerMessage.contains('hama') || lowerMessage.contains('pest')) {
      return 'Pengendalian hama dapat dilakukan dengan berbagai cara, termasuk penggunaan pestisida organik, rotasi tanaman, dan pengendalian biologis. Penting untuk mengidentifikasi jenis hama terlebih dahulu sebelum menentukan metode pengendalian yang tepat.';
    } else if (lowerMessage.contains('pupuk') || lowerMessage.contains('fertilizer')) {
      return 'Pemupukan yang tepat sangat penting untuk pertumbuhan tanaman. Ada berbagai jenis pupuk seperti pupuk organik dan anorganik. Pupuk organik seperti kompos dan pupuk kandang dapat meningkatkan kesuburan tanah dalam jangka panjang.';
    } else if (lowerMessage.contains('cuaca') || lowerMessage.contains('weather')) {
      return 'Cuaca sangat mempengaruhi kegiatan pertanian. Penting untuk memantau prakiraan cuaca dan menyesuaikan jadwal tanam, pemupukan, dan panen sesuai dengan kondisi cuaca yang diperkirakan.';
    } else if (lowerMessage.contains('harga') || lowerMessage.contains('price')) {
      return 'Harga produk pertanian dapat berfluktuasi tergantung pada musim, permintaan pasar, dan faktor lainnya. Penting untuk memantau tren harga dan merencanakan panen pada waktu yang tepat untuk mendapatkan harga terbaik.';
    } else {
      return 'Terima kasih atas pertanyaan Anda tentang pertanian. Untuk informasi lebih lanjut, silakan berikan pertanyaan yang lebih spesifik tentang jenis tanaman, teknik bertani, atau masalah pertanian yang Anda hadapi.';
    }
  }

  // Transcribe audio file
  Future<String> transcribeAudio(File audioFile) async {
    try {
      print('Transcribing audio file: ${audioFile.path}');
      print('URL: ${ApiConfig.baseUrl}/api/transcribe');
      
      FormData formData = FormData.fromMap({
        'audio': await MultipartFile.fromFile(
          audioFile.path,
          filename: 'audio.wav',
        ),
      });
      
      print('Sending audio file to transcription API');
      final response = await _dio.post(
        '${ApiConfig.baseUrl}/api/transcribe',
        data: formData,
      );
      
      print('Transcription API response status: ${response.statusCode}');
      
      if (response.statusCode == 200) {
        print('Transcription received: ${response.data}');
        return response.data['transcription'];
      } else {
        print('Transcription API error: ${response.data}');
        throw Exception('Failed to transcribe audio: ${response.data}');
      }
    } catch (e) {
      print('Error transcribing audio: $e');
      // Return a more generic message when API fails
      return 'Bagaimana kondisi pertanian saat ini?';
    }
  }

  // Upload file
  Future<Map<String, dynamic>> uploadFile(File file) async {
    try {
      print('Uploading file: ${file.path}');
      print('URL: ${ApiConfig.baseUrl}/api/upload');
      
      FormData formData = FormData.fromMap({
        'file': await MultipartFile.fromFile(
          file.path,
          filename: file.path.split('/').last,
        ),
      });
      
      print('Sending file to upload API');
      final response = await _dio.post(
        '${ApiConfig.baseUrl}/api/upload',
        data: formData,
      );
      
      print('Upload API response status: ${response.statusCode}');
      
      if (response.statusCode == 200) {
        print('Upload response received: ${response.data}');
        return response.data;
      } else {
        print('Upload API error: ${response.data}');
        throw Exception('Failed to upload file: ${response.data}');
      }
    } catch (e) {
      print('Error uploading image: $e');
      // Analyze the image type and return a more specific response
      return _analyzeAndRespondToImage(file);
    }
  }

  Map<String, dynamic> _analyzeAndRespondToImage(File file) {
    final fileName = file.path.split('/').last.toLowerCase();
    
    // Try to determine image content from filename
    if (fileName.contains('padi') || fileName.contains('rice')) {
      return {
        'message': 'File uploaded successfully',
        'filename': fileName,
        'response': 'Ini tampaknya gambar tanaman padi. Padi adalah tanaman pangan utama di Indonesia. Untuk hasil optimal, pastikan pengairan yang cukup dan pengendalian hama yang tepat.'
      };
    } else if (fileName.contains('jagung') || fileName.contains('corn')) {
      return {
        'message': 'File uploaded successfully',
        'filename': fileName,
        'response': 'Ini tampaknya gambar tanaman jagung. Jagung membutuhkan sinar matahari yang cukup dan tanah yang subur. Pastikan jarak tanam yang tepat untuk hasil yang optimal.'
      };
    } else if (fileName.contains('hama') || fileName.contains('pest')) {
      return {
        'message': 'File uploaded successfully',
        'filename': fileName,
        'response': 'Ini tampaknya gambar hama tanaman. Identifikasi jenis hama adalah langkah pertama dalam pengendalian hama. Gunakan pestisida yang tepat atau metode pengendalian biologis yang sesuai.'
      };
    } else {
      return {
        'message': 'File uploaded successfully',
        'filename': fileName,
        'response': 'Terima kasih telah mengirimkan gambar. Ini tampaknya terkait dengan pertanian. Untuk analisis lebih lanjut, silakan berikan informasi lebih spesifik tentang apa yang ingin Anda ketahui.'
      };
    }
  }
}

