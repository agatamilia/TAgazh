import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/api_service.dart';
import '../services/location_service.dart';
import '../services/permission_service.dart';
import '../models/weather_data.dart';

class WeatherWidget extends StatefulWidget {
  const WeatherWidget({Key? key}) : super(key: key);

  @override
  State<WeatherWidget> createState() => _WeatherWidgetState();
}

class _WeatherWidgetState extends State<WeatherWidget> {
  final ApiService _apiService = ApiService();
  bool _isLoading = true;
  String _errorMessage = '';
  WeatherData? _weatherData;
  String _locationName = 'Memuat lokasi...';

  @override
  void initState() {
    super.initState();
    _loadWeatherData();
  }

  Future<void> _loadWeatherData() async {
    try {
      setState(() {
        _isLoading = true;
        _errorMessage = '';
      });
      
      // Get current location
      print('Getting current location for weather data');
      final position = await LocationService.getCurrentPosition();
      
      if (position != null) {
        // Get place name
        print('Getting place name for coordinates: ${position.latitude}, ${position.longitude}');
        final placeName = await LocationService.getPlaceFromCoordinates(
          position.latitude,
          position.longitude,
        );
        
        if (placeName != null) {
          setState(() {
            _locationName = placeName;
          });
        }
        
        // Get weather data
        print('Fetching weather data from API');
        final weatherData = await _apiService.getWeather(
          position.latitude,
          position.longitude,
        );
        
        setState(() {
          _weatherData = weatherData;
          _isLoading = false;
        });
      } else {
        // Use mock data if location is not available
        final mockPosition = LocationService.getMockPosition();
        final placeName = await LocationService.getPlaceFromCoordinates(
          mockPosition.latitude,
          mockPosition.longitude,
        );
        
        if (placeName != null) {
          setState(() {
            _locationName = placeName;
          });
        }
        
        final weatherData = await _apiService.getWeather(
          mockPosition.latitude,
          mockPosition.longitude,
        );
        
        setState(() {
          _weatherData = weatherData;
          _isLoading = false;
        });
      }
    } catch (e) {
      print('Error loading weather data: $e');
      setState(() {
        _isLoading = false;
        _errorMessage = 'Gagal memuat data cuaca';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 2,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Icon(
                          Icons.location_on,
                          size: 14,
                          color: Colors.green,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          _locationName,
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      DateFormat('EEEE, d MMMM yyyy', 'id_ID').format(DateTime.now()),
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.grey[600],
                      ),
                    ),
                  ],
                ),
              ),
              _isLoading 
                  ? const SizedBox(
                      width: 40,
                      height: 40,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        valueColor: AlwaysStoppedAnimation<Color>(Colors.green),
                      ),
                    )
                  : _weatherData != null
                      ? _buildWeatherIcon(_weatherData!.condition)
                      : const Icon(Icons.cloud_off, color: Colors.grey),
            ],
          ),
          const SizedBox(height: 8),
          _isLoading
              ? const LinearProgressIndicator(
                  backgroundColor: Colors.transparent,
                  valueColor: AlwaysStoppedAnimation<Color>(Colors.green),
                )
              : _errorMessage.isNotEmpty
                  ? Row(
                      children: [
                        Icon(Icons.error_outline, color: Colors.red[300], size: 16),
                        const SizedBox(width: 4),
                        Expanded(
                          child: Text(
                            _errorMessage,
                            style: TextStyle(
                              color: Colors.red[300],
                              fontSize: 12,
                            ),
                          ),
                        ),
                        TextButton(
                          onPressed: _loadWeatherData,
                          child: const Text('Coba Lagi', style: TextStyle(fontSize: 12)),
                        ),
                      ],
                    )
                  : _weatherData != null
                      ? Row(
                          children: [
                            Text(
                              '${_weatherData!.temperature.round()}°C',
                              style: const TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                '${_weatherData!.description} - ${_weatherData!.advice}',
                                style: const TextStyle(
                                  fontSize: 12,
                                  color: Colors.green,
                                ),
                              ),
                            ),
                          ],
                        )
                      : const SizedBox(),
        ],
      ),
    );
  }

  Widget _buildWeatherIcon(String condition) {
    IconData icon;
    Color color;
    
    switch (condition) {
      case 'sunny':
        icon = Icons.wb_sunny;
        color = Colors.amber;
        break;
      case 'cloudy':
        icon = Icons.cloud;
        color = Colors.grey;
        break;
      case 'rainy':
        icon = Icons.grain;
        color = Colors.blue;
        break;
      default:
        icon = Icons.cloud;
        color = Colors.grey;
    }
    
    return Container(
      width: 40,
      height: 40,
      decoration: BoxDecoration(
        color: color.withOpacity(0.2),
        shape: BoxShape.circle,
      ),
      child: Icon(
        icon,
        color: color,
        size: 24,
      ),
    );
  }
}

