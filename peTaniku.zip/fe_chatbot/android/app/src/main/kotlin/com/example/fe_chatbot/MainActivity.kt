package com.example.fe_chatbot

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
